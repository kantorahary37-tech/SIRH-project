from flask import Flask, render_template, request, redirect, url_for, flash
from models import db
import mysql.connector
from models.agents import Agent
from models.mouvements import Mouvement
from flask import session
from models.mouvements import enregistrer_mouvement

print(enregistrer_mouvement)
from werkzeug.utils import secure_filename



from models.documents import Document
import pandas as pd
import os
import math
from datetime import date
from flask import request, jsonify
from datetime import date
from collections import defaultdict
from sqlalchemy import extract
from sqlalchemy import or_
from flask import request
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.security import generate_password_hash

hash_admin = generate_password_hash(
    "Admin1234!",
    method="pbkdf2:sha256",
    salt_length=16
)

print(hash_admin)



from functools import wraps





LISTE_CORPS = [
    "Inspecteur de trésor",
    "Percepteur Principal des Finances",
    "Percepteur des Finances",
    "Controleur du Trésor",
    "Comptable du Trésor",
    "Planificateur principal",
    "Magistrat",
    "Concepteur",
    "Planificateur",
    "Fonctionnaire de la catégorie VII",
    "Attaché de planification",
    "Réalisateur",
    "Réalisateur adjoint",
    "Technicien supérieur",
    "Encadreur",
    "Opérateur",
    "Sous opérateur",
    "Contractuel",
    "ELD",
    "ECD",
    "Autre",
    "Agent de police",
    "Agent détaché"
]



app = Flask(__name__)
app.secret_key = "dev"  # nécessaire pour les messages flash
app.secret_key = "sirh_secret_key"  # à sécuriser plus tard

# === CONFIG BASE DE DONNÉES ===
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root@localhost/sirh'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)

def get_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="sirh"
    )

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.before_request
def verifier_connexion():
    # Routes accessibles sans connexion
    routes_libres = [
        'login',
        'logout',
        'static'
    ]

    # request.endpoint None → laisser passer (ex: favicon, assets)
    if request.endpoint is None:
        return

    # Si l'utilisateur n'est pas connecté ET que la route n'est pas libre
    if 'user_id' not in session and request.endpoint not in routes_libres:
        return redirect(url_for('login'))


# === ROUTES PRINCIPALES ===
@app.route('/')
@app.route("/dashboard")

@login_required
def dashboard():
    today = date.today()

    # --- KPI ---
    total_actifs = Agent.query.filter_by(statut="Actif").count()
    total_inactifs = Agent.query.filter_by(statut="Inactif").count()

    # Nouveaux agents du mois
    nouveaux_agents = Agent.query.filter(
        extract("month", Agent.date_premiere_prise_service) == today.month,
        extract("year", Agent.date_premiere_prise_service) == today.year
    ).count()

    # Proches de la retraite (55 à 59 ans)
    agents_avec_date = Agent.query.filter(Agent.date_naissance.isnot(None)).all()
    proches_retraite = 0

    for a in agents_avec_date:
        age = today.year - a.date_naissance.year - (
            (today.month, today.day) < (a.date_naissance.month, a.date_naissance.day)
        )
        if 55 <= age < 60:
            proches_retraite += 1

    # Derniers agents ajoutés ce mois (max 5)
    derniers_agents = Agent.query.filter(
        extract("month", Agent.date_premiere_prise_service) == today.month,
        extract("year", Agent.date_premiere_prise_service) == today.year
    ).order_by(Agent.date_premiere_prise_service.desc()).limit(5).all()

    return render_template(
        "dashboard.html",
        page="dashboard",
        total_actifs=total_actifs,
        total_inactifs=total_inactifs,
        nouveaux_agents=nouveaux_agents,
        proches_retraite=proches_retraite,
        derniers_agents=derniers_agents
    )



@app.route("/recherche")
def recherche():
    q = request.args.get("q", "").strip()

    agents = []
    if q:
        agents = Agent.query.filter(
            (Agent.agent.ilike(f"%{q}%")) |
            (Agent.matricule.ilike(f"%{q}%")) |
            (Agent.genre.ilike(f"%{q}%")) |
            (Agent.poste_comptable.ilike(f"%{q}%")) |
            (Agent.poste_type.ilike(f"%{q}%")) 
            
        ).all()

    return render_template(
        "recherche.html",
        agents=agents,
        q=q,
        page="recherche"
    )

@app.route("/messages")
def messages():
    return render_template("messages.html", page="messages")


@app.route("/notifications")
def notifications():
    return render_template("notifications.html", page="notifications")


@app.route("/parametres")
def parametres():
    return render_template("parametres.html", page="parametres")


@app.route("/profil")
def profil():
    return render_template("profil.html", page="profil")


@app.route('/personnels_actifs')
def personnels_actifs():
    agents = Agent.query.filter_by(statut="Actif").all()
    return render_template('personnels_actifs.html', agents=agents, page='actifs')

@app.route('/api/agents_inactifs')
def api_agents_inactifs():
    agents = Agent.query.filter_by(statut="Inactif").all()
    data = []
    for a in agents:
        data.append({
            "id": a.id,
            "matricule": a.matricule,
            "agent": a.agent,
            "telephone": a.telephone,
            "genre": a.genre,
            "date_naissance": a.date_naissance.isoformat() if a.date_naissance else None,
            "statut": a.statut,
            "corps": a.corps,
            "poste_type": a.poste_type,
            "poste_comptable": a.poste_comptable,
            "date_premiere_prise_service": a.date_premiere_prise_service.isoformat() if a.date_premiere_prise_service else None,
            "promotion_corps": a.promotion_corps,
            "permis_conduire": a.permis_conduire,
            "epoux_epouse_nom_poste": a.epoux_epouse_nom_poste,
            "historique_formations": a.historique_formations,
            "motif_inactivite": a.motif_inactivite,
            "date_inactivite": a.date_inactivite.isoformat() if a.date_inactivite else None,
            "commentaire_inactivite": a.commentaire_inactivite
        })
    return jsonify(data)

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads') 
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER 
print("Fichier sauvegardé dans :", )
@app.route('/importer_agents', methods=['POST'])
def importer_agents():
    fichier = request.files.get('fichier')

    if not fichier or fichier.filename == '':
        flash("Aucun fichier sélectionné.", "danger")
        return redirect(url_for('personnels_actifs'))

    # === Sauvegarde fichier ===
    filename = secure_filename(fichier.filename)
    chemin_fichier = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    try:
        fichier.save(chemin_fichier)
        print(f"[INFO] Fichier sauvegardé : {chemin_fichier}")
    except Exception as e:
        flash(f"Erreur sauvegarde : {e}", "danger")
        return redirect(url_for('personnels_actifs'))

    # === Lecture Excel ===
    try:
        df = pd.read_excel(chemin_fichier)
        df.columns = df.columns.str.strip()  # supprime espaces invisibles
        print("[INFO] Colonnes Excel :", df.columns.tolist())
    except Exception as e:
        flash(f"Erreur lecture Excel : {e}", "danger")
        return redirect(url_for('personnels_actifs'))

    # === Sécurisation colonnes attendues ===
    colonnes_attendues = [
        'agents', 'matricule', 'genre',
        'date_naissance', 'telephone', 'statut',
        'poste_type', 'poste_comptable', 'corps',
        'promotion_corps', 'date_premiere_prise_service',
        'permis_conduire', 'historique_formations',
        'epoux_epouse_nom_poste'
    ]

    for col in colonnes_attendues:
        if col not in df.columns:
            df[col] = None

    # === Nettoyage dates ===
    def safe_date(value):
        try:
            if pd.isna(value):
                return None
            return pd.to_datetime(value).date()
        except:
            return None

    df["date_naissance"] = df["date_naissance"].apply(safe_date)
    df["date_premiere_prise_service"] = df["date_premiere_prise_service"].apply(safe_date)

    total_ajoutes = 0
    total_updates = 0
    erreurs = 0

    for _, row in df.iterrows():

        matricule = str(row.get("matricule")).strip() if row.get("matricule") else None

        if not matricule:
            erreurs += 1
            continue

        try:
            agent_exist = Agent.query.filter_by(matricule=matricule).first()

            if agent_exist:
                # 🔄 UPDATE si existe
                agent_exist.agent = row.get("agents")
                agent_exist.genre = row.get("genre")
                agent_exist.date_naissance = row.get("date_naissance")
                agent_exist.telephone = row.get("telephone")
                agent_exist.statut = row.get("statut") or "Actif"
                agent_exist.poste_type = row.get("poste_type")
                agent_exist.poste_comptable = row.get("poste_comptable")
                agent_exist.corps = row.get("corps")
                agent_exist.promotion_corps = row.get("promotion_corps")
                agent_exist.date_premiere_prise_service = row.get("date_premiere_prise_service")
                agent_exist.permis_conduire = row.get("permis_conduire")
                agent_exist.historique_formations = row.get("historique_formations")
                agent_exist.epoux_epouse_nom_poste = row.get("epoux_epouse_nom_poste")

                total_updates += 1

            else:
                # ➕ INSERT si nouveau
                nouvel_agent = Agent(
                    agent=row.get("agents"),
                    matricule=matricule,
                    genre=row.get("genre"),
                    date_naissance=row.get("date_naissance"),
                    telephone=row.get("telephone"),
                    statut=row.get("statut") or "Actif",
                    poste_type=row.get("poste_type"),
                    poste_comptable=row.get("poste_comptable"),
                    corps=row.get("corps"),
                    promotion_corps=row.get("promotion_corps"),
                    date_premiere_prise_service=row.get("date_premiere_prise_service"),
                    permis_conduire=row.get("permis_conduire"),
                    historique_formations=row.get("historique_formations"),
                    epoux_epouse_nom_poste=row.get("epoux_epouse_nom_poste"),
                )

                db.session.add(nouvel_agent)
                total_ajoutes += 1

        except Exception as e:
            erreurs += 1
            print(f"[ERREUR] Matricule {matricule} : {e}")

    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        flash(f"Erreur commit BDD : {e}", "danger")
        return redirect(url_for('personnels_actifs'))

    flash(
        f"Import terminé : {total_ajoutes} ajoutés — {total_updates} mis à jour — {erreurs} erreurs",
        "success"
    )

    return redirect(url_for('personnels_actifs'))
@app.route('/personnels_inactifs')
def personnels_inactifs():
    agents = Agent.query.filter_by(statut="Inactif").all()
    return render_template('personnels_inactifs.html', agents=agents, page='inactifs')




@app.route('/statistiques')

def statistiques():

    # --- STATUT ---
    statut_data = db.session.query(
        Agent.statut, db.func.count(Agent.id)
    ).group_by(Agent.statut).all()

    labels_statut = [s for s, _ in statut_data]
    data_statut = [c for _, c in statut_data]

    # --- GENRE ---
    genre_data = db.session.query(
        Agent.genre, db.func.count(Agent.id)
    ).group_by(Agent.genre).all()

    labels_genre = [g for g, _ in genre_data]
    data_genre = [c for _, c in genre_data]

    # --- CORPS ---
    corps_data = db.session.query(
        Agent.corps, db.func.count(Agent.id)
    ).group_by(Agent.corps).all()

    labels_corps = [c for c, _ in corps_data]
    data_corps = [nb for _, nb in corps_data]

    # --- TRANCHES D'ÂGE ---
    tranches = {
        "-30": 0,
        "30-39": 0,
        "40-49": 0,
        "50-59": 0,
        "60+": 0
    }

    agents = Agent.query.filter(Agent.date_naissance.isnot(None)).all()

    today = date.today()

    for agent in agents:
        age = today.year - agent.date_naissance.year - (
            (today.month, today.day) < (agent.date_naissance.month, agent.date_naissance.day)
        )

        if age < 30:
            tranches["-30"] += 1
        elif age < 40:
            tranches["30-39"] += 1
        elif age < 50:
            tranches["40-49"] += 1
        elif age < 60:
            tranches["50-59"] += 1
        else:
            tranches["60+"] += 1

    labels_age = list(tranches.keys())
    data_age = list(tranches.values())

    AGE_RETRAITE = 60
    PROCHE_RETRAITE = 5  # agents dans les 5 ans avant retraite

    agents_proches_retraite = []

    for agent in agents:
        age = today.year - agent.date_naissance.year - (
            (today.month, today.day) < (agent.date_naissance.month, agent.date_naissance.day)
        )
        if AGE_RETRAITE - age <= PROCHE_RETRAITE:
            agents_proches_retraite.append({
                'agent': agent.agent,
                'matricule': agent.matricule,
                'date_naissance': agent.date_naissance,
                'age': age,
                'annees_restantes': AGE_RETRAITE - age
            })


    # --- TOTALS (pour les cards) ---
    total_agents = Agent.query.count()
    agents_actifs = Agent.query.filter_by(statut='Actif').count()
    agents_inactifs = Agent.query.filter_by(statut='Inactif').count()

    # ✅ RETURN OBLIGATOIRE
    return render_template(
    'statistiques.html',
    page='stats',
    labels_statut=labels_statut,
    data_statut=data_statut,
    labels_genre=labels_genre,
    data_genre=data_genre,
    labels_corps=labels_corps,
    data_corps=data_corps,
    labels_age=labels_age,
    data_age=data_age,
    agents_proches_retraite=agents_proches_retraite  # ⚡ on passe la liste au template
)




def calcul_age(date_naissance):
    today = date.today()
    return today.year - date_naissance.year - (
        (today.month, today.day) < (date_naissance.month, date_naissance.day)
    )

@app.route('/repartition')
def repartition():

    corps = request.args.get('corps')
    statut = request.args.get('statut')
    poste_type = request.args.get('poste_type')
    poste_comptable = request.args.get('poste_comptable')

    query = Agent.query

    if corps:
        query = query.filter(Agent.corps == corps)

    if statut:
        query = query.filter(Agent.statut == statut)

    if poste_type:
        query = query.filter(Agent.poste == poste_type)

    if poste_comptable:
        query = query.filter(Agent.poste_comptable == poste_comptable)

    agents = query.all()

    # Listes DISTINCT pour filtres
    corps_list = [c[0] for c in db.session.query(Agent.corps).distinct().all() if c[0]]
    statut_list = [s[0] for s in db.session.query(Agent.statut).distinct().all() if s[0]]
    poste_type_list = [p[0] for p in db.session.query(Agent.poste_type).distinct().all() if p[0]]
    poste_comptable_list = [pc[0] for pc in db.session.query(Agent.poste_comptable).distinct().all() if pc[0]]

    return render_template(
        'repartition.html',
        agents=agents,
        corps_list=corps_list,
        statut_list=statut_list,
        poste_type_list=poste_type_list,
        poste_comptable_list=poste_comptable_list,
        selected_corps=corps,
        selected_statut=statut,
        selected_poste_type=poste_type,
        selected_pc=poste_comptable
    )

@app.route("/mouvements")
def mouvements():

    mouvements = (
        db.session.query(
            Mouvement.id,
            Agent.agent.label("agent"),
            Mouvement.date_mouvement,
            Mouvement.type_mouvement,
            Mouvement.champ_modifie,
            Mouvement.ancienne_valeur,
            Mouvement.nouvelle_valeur,
            Mouvement.auteur
        )
        .join(Agent, Mouvement.agents_id == Agent.id)
        .order_by(Mouvement.date_mouvement.desc())
        .all()
    )

    return render_template(
        "mouvements.html",
        mouvements=mouvements,
        page="mouvements"
    )

    



@app.route('/ajouter_agent', methods=['GET', 'POST'])
def ajouter_agent():
    if request.method == 'POST':

        # Récupération des champs
        agent_nom = request.form['agent']
        matricule = request.form['matricule']
        genre = request.form.get("genre")
        date_naissance = request.form['date_naissance']
        telephone = request.form.get('telephone')
        statut = request.form.get('statut', 'Actif')

        epoux_epouse_nom_poste = request.form.get('epoux_epouse_nom_poste')
        poste_type = request.form['poste_type']
        poste_comptable = request.form['poste_comptable']
        corps = request.form['corps']

        historique_formations = request.form.get('historique_formations')
        date_premiere_prise_service = request.form['date_premiere_prise_service']
        promotion_corps = request.form.get('promotion_corps')
        permis_conduire = request.form.get('permis_conduire')

        # Création de l'agent
        nouvel_agent = Agent(
            agent=agent_nom,
            matricule=matricule,
            genre=genre,
            date_naissance=date_naissance,
            telephone=telephone,
            statut=statut,
            epoux_epouse_nom_poste=epoux_epouse_nom_poste,
            corps=corps,
            poste_type=poste_type,
            poste_comptable=poste_comptable,
            historique_formations=historique_formations,
            date_premiere_prise_service=date_premiere_prise_service,
            promotion_corps=promotion_corps,
            permis_conduire=permis_conduire
        )

        # 🔹 1. Insertion agent
        db.session.add(nouvel_agent)
        db.session.commit()  # ⬅️ indispensable pour avoir nouvel_agent.id

        # 🔹 2. Enregistrement du mouvement
        enregistrer_mouvement(
            agent_id=nouvel_agent.id,
            champ="agent",
            ancienne_valeur=None,
            nouvelle_valeur=nouvel_agent.agent,
            auteur=session.get("username", "system"),
            type_mouvement="creation"
        )

        db.session.commit()

        flash("Agent ajouté avec succès !", "success")
        return redirect(url_for('personnels_actifs'))

    return render_template('ajouter_agent.html', page='ajouter')



@app.route('/modifier_agent/<int:id>', methods=['POST'])
def modifier_agent(id):
    agent = Agent.query.get_or_404(id)
    data = request.get_json()   # ✅ IMPORTANT

    anciennes_valeurs = {
        "agent": agent.agent,
        "matricule": agent.matricule,
        "telephone": agent.telephone,
        "genre": agent.genre,
        "date_naissance": agent.date_naissance,
        "statut": agent.statut,
        "corps": agent.corps,
        "poste_type": agent.poste_type,
        "poste_comptable": agent.poste_comptable,
        "date_premiere_prise_service": agent.date_premiere_prise_service,
        "historique_formations": agent.historique_formations,
        "epoux_epouse_nom_poste": agent.epoux_epouse_nom_poste,
        "promotion_corps": agent.promotion_corps,
        "permis_conduire": agent.permis_conduire
    }


    agent.agent = data.get('agent')
    agent.matricule = data.get('matricule')
    agent.telephone = data.get('telephone')
    agent.genre = data.get('genre')
    agent.date_naissance = data.get('date_naissance')
    agent.statut = data.get('statut')
    agent.corps = data.get('corps')
    agent.poste_type = data.get('poste_type')
    agent.poste_comptable = data.get('poste_comptable')
    agent.date_premiere_prise_service = data.get('date_premiere_prise_service')
    agent.historique_formations = data.get('historique_formations')
    agent.epoux_epouse_nom_poste = data.get('epoux_epouse_nom_poste')
    agent.promotion_corps = data.get('promotion_corps')
    agent.permis_conduire = data.get('permis_conduire')


    for champ, ancienne_valeur in anciennes_valeurs.items():
        nouvelle_valeur = data.get(champ)

        ancienne_str = (
            ancienne_valeur.isoformat()
            if hasattr(ancienne_valeur, "isoformat")
            else str(ancienne_valeur) if ancienne_valeur is not None else ""
        )

        nouvelle_str = (
            str(nouvelle_valeur)
            if nouvelle_valeur is not None else ""
        )

        if ancienne_str != nouvelle_str:
            enregistrer_mouvement(
                agent_id=agent.id,
                champ=champ,
                ancienne_valeur=ancienne_str,
                nouvelle_valeur=nouvelle_str,
                auteur=session.get("username", "system"),
                type_mouvement="modification"
            )

    db.session.commit()

    return jsonify({
        "success": True,
        "message": "Agent actif modifié avec succès"
    })


@app.route('/api/agent/<int:id>')
def api_get_agent(id):
    agent = Agent.query.get(id)
    if not agent:
        return {"error": "Agent introuvable"}, 404

    return {
        "id": agent.id,
        "matricule": agent.matricule,
        "agent": agent.agent,   # NOM COMPLET
        "telephone": agent.telephone,
        "genre": agent.genre,
        "date_naissance": agent.date_naissance.isoformat() if agent.date_naissance else None,
        "statut": agent.statut,
        "corps": agent.corps,
        "poste_type": agent.poste_type,
        "poste_comptable": agent.poste_comptable,
        "date_premiere_prise_service": agent.date_premiere_prise_service.isoformat() if agent.date_premiere_prise_service else None,
        "historique_formations": agent.historique_formations,
        "epoux_epouse_nom_poste": agent.epoux_epouse_nom_poste,
        "promotion_corps": agent.promotion_corps,
        

        # ➕ CHAMPS D’INACTIVITÉ (à ajouter ici)
        "motif_inactivite": agent.motif_inactivite,
        "date_inactivite": agent.date_inactivite.isoformat() if agent.date_inactivite else None,
        "commentaire_inactivite": agent.commentaire_inactivite
    }

from datetime import date

@app.route('/api/agent/inactiver/<int:id>', methods=['POST'])
def api_inactiver(id):
    agent = Agent.query.get_or_404(id)
    data = request.get_json()

    #  Sauvegarde ancien statut
    ancien_statut = agent.statut

    #  Données reçues
    motif = data.get("motif_inactivite")
    details = data.get("details_motif")
    commentaire = data.get("commentaire_inactivite")
    date_inact = data.get("date_inactivite")

    #  Mise à jour agent
    agent.statut = "Inactif"
    agent.motif_inactivite = motif
    agent.commentaire_inactivite = commentaire

    if date_inact:
        agent.date_inactivite = date.fromisoformat(date_inact)

    #  Mouvement RH structuré
    if ancien_statut != agent.statut:
        nouvelle_valeur = "Inactif"
        if motif:
            nouvelle_valeur += f" – {motif}"
        if details:
            nouvelle_valeur += f" ({details})"

        mouvement = Mouvement(
            agents_id=agent.id,
            type_mouvement="Inactivité",
            champ_modifie="statut",
            ancienne_valeur=ancien_statut,
            nouvelle_valeur=nouvelle_valeur,
            auteur=session.get("username", "system")
        )

        db.session.add(mouvement)

    # Commit unique
    db.session.commit()

    return jsonify({"success": True})




@app.route('/api/agent/update/<int:id>', methods=['POST'])
def api_update_agent(id):
    agent = Agent.query.get_or_404(id)
    data = request.get_json() or {}

    #  Stocker les anciennes valeurs
    anciennes_valeurs = {
        "agent": agent.agent,
        "matricule": agent.matricule,
        "telephone": agent.telephone,
        "genre": agent.genre,
        "date_naissance": agent.date_naissance,
        "statut": agent.statut,
        "corps": agent.corps,
        "poste_type": agent.poste_type,
        "poste_comptable": agent.poste_comptable,
        "historique_formations": agent.historique_formations,
        "epoux_epouse_nom_poste": agent.epoux_epouse_nom_poste,
        "promotion_corps": agent.promotion_corps,
        "permis_conduire": agent.permis_conduire,
        "motif_inactivite": agent.motif_inactivite,
        "date_inactivite": agent.date_inactivite,
        "commentaire_inactivite": agent.commentaire_inactivite
    }

    # 🔹 Mettre à jour les champs
    for champ, ancienne_valeur in anciennes_valeurs.items():
        nouvelle_valeur = data.get(champ, ancienne_valeur)

        # Parse dates si nécessaire
        if champ in ["date_naissance", "date_premiere_prise_service", "date_inactivite"] and nouvelle_valeur:
            try:
                nouvelle_valeur = date.fromisoformat(nouvelle_valeur)
            except Exception:
                nouvelle_valeur = ancienne_valeur

        setattr(agent, champ, nouvelle_valeur)

        # 🔹 Enregistrer le mouvement si la valeur a changé
        if str(ancienne_valeur) != str(nouvelle_valeur):
            # type_mouvement = 'modification' ou 'reactivation' si statut
            type_mouv = "modification"
            if champ == "statut" and ancienne_valeur == "Inactif" and nouvelle_valeur == "Actif":
                type_mouv = "reactivation"
            elif champ == "statut" and ancienne_valeur == "Actif" and nouvelle_valeur == "Inactif":
                type_mouv = "inactivation"

            enregistrer_mouvement(
                agent_id=agent.id,
                champ=champ,
                ancienne_valeur=ancienne_valeur,
                nouvelle_valeur=nouvelle_valeur,
                auteur=session.get("username", "system"),
                type_mouvement=type_mouv
            )

    # 🔹 Nettoyage si réactivation
    if anciennes_valeurs["statut"] == "Inactif" and agent.statut == "Actif":
        agent.motif_inactivite = None
        agent.date_inactivite = None
        agent.commentaire_inactivite = None

    db.session.commit()

    return jsonify({
        "success": True,
        "agent": {
            "id": agent.id,
            "matricule": agent.matricule,
            "agent": agent.agent,
            "telephone": agent.telephone,
            "genre": agent.genre,
            "date_naissance": agent.date_naissance.isoformat() if agent.date_naissance else None,
            "statut": agent.statut,
            "corps": agent.corps,
            "poste_type": agent.poste_type,
            "poste_comptable": agent.poste_comptable,
            "date_premiere_prise_service": agent.date_premiere_prise_service.isoformat() if agent.date_premiere_prise_service else None,
            "promotion_corps": agent.promotion_corps,
            "permis_conduire": agent.permis_conduire,
            "epoux_epouse_nom_poste": agent.epoux_epouse_nom_poste,
            "historique_formations": agent.historique_formations,
            "motif_inactivite": agent.motif_inactivite,
            "date_inactivite": agent.date_inactivite.isoformat() if agent.date_inactivite else None,
            "commentaire_inactivite": agent.commentaire_inactivite
        }
    })


@app.route('/supprimer_agent/<int:id>')
def supprimer_agent(id):
    agent = Agent.query.get_or_404(id)
    db.session.delete(agent)
    db.session.commit()
    flash("Agent supprimé avec succès !", "info")
    return redirect(url_for('personnels_actifs'))




@app.route('/changer_statut/<int:id>', methods=['POST'])
def changer_statut(id):
    agent = Agent.query.get_or_404(id)

    ancien_statut = agent.statut

    # Changement
    agent.statut = "Inactif" if agent.statut == "Actif" else "Actif"
    nouveau_statut = agent.statut

    # 🔥 Enregistrement du mouvement
    if ancien_statut != nouveau_statut:
        enregistrer_mouvement(
            agent_id=agent.id,
            type_mouvement="modification",
            champ="statut",
            ancienne_valeur=ancien_statut,
            nouvelle_valeur=nouveau_statut
        )

    db.session.commit()

    flash(f"Statut de {agent.nom} changé en {agent.statut}", "warning")
    return redirect(url_for('personnels_inactifs'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute(
            "SELECT * FROM users WHERE username = %s AND password = %s",
            (username, password)
        )
        user = cursor.fetchone()

        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            return redirect(url_for('dashboard'))
        else:
            flash("Identifiants incorrects", "danger")

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# === CRÉATION DES TABLES SI NON EXISTANTES ===
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
